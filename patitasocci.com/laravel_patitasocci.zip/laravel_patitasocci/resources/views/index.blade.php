<!DOCTYPE html>
<html lang="es">
<head>
    <!-- Meta Tags -->
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta name="author" content="" />

    <!-- Favicon -->
    <link rel="icon" href="{{ asset('images/favicon.ico') }}" type="image/png">
    <link rel="apple-touch-icon" sizes="180x180" href="{{ asset('apple-touch-icon.png') }}">
    <link rel="icon" type="image/png" sizes="32x32" href="{{ asset('favicon-32x32.png') }}">
    <link rel="icon" type="image/png" sizes="16x16" href="{{ asset('favicon-16x16.png') }}">
    <link rel="manifest" href="{{ asset('site.webmanifest') }}">

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Dosis:400,500|Poppins:400,700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">

    <!-- Js y Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>


    <!-- CSS Libraries -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.1.3/assets/owl.carousel.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="{{ asset('lib/flaticon/font/flaticon.css') }}" rel="stylesheet">
    <link href="{{ asset('lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css') }}" rel="stylesheet" />

    <!-- Custom CSS -->
    <link href="{{ asset('css/bootstrap.css') }}" rel="stylesheet">
    <link href="{{ asset('css/styles.css') }}" rel="stylesheet">
    <link href="{{ asset('css/responsive.css') }}" rel="stylesheet">

    <title>Patitas Occi</title>
</head>

<body>
<div class="hero_area">
    <!-- Sección Header -->
    <header class="header_section">
        <div class="container-fluid">
            <nav class="navbar navbar-expand-lg custom_nav-container">
                <a class="navbar-brand" href="{{ url('/') }}">
                    <img src="{{ asset('images/logo (2).png') }}" alt="Logo">
                    <span>Patitas Occi</span>
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                        data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                        aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <button type="button" class="close-btn" aria-label="Close" id="closeMenuBtn">&times;</button>

                    <ul class="navbar-nav me-auto mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link" href="{{ url('service') }}">Servicio</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{{ url('pet') }}">Adopciones</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{{ url('clinic') }}">Nosotros</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{{ url('contact') }}">Contactanos</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{{ url('buy') }}">Productos</a>
                        </li>
                    </ul>

                    <!-- Para pantallas pequeñas -->
                    <div class="d-block d-lg-none mt-0 text-center">
                        <a href="{{ url('login') }}" class="btn btn-primary w-75 mb-2">Iniciar Sesión</a>
                        <a href="{{ url('register') }}" class="btn btn-secondary w-75">Registrarse</a>
                    </div>
                    
                    <div class="space"></div>

                    <!-- Ícono de usuario para pantallas grandes -->
                    <div class="d-none d-lg-flex align-items-center">
                    <div class="dropdown">
    <a href="#" class="nav-link dropdown-toggle" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
        <img src="{{ asset('images/usuario.png') }}" alt="User Icon" class="user-icon">
    </a>
    <ul class="dropdown-menu" aria-labelledby="userDropdown">
        @if (Auth::check())
            <li><a class="dropdown-item" href="{{ url('/user-list') }}">Dashboard</a></li>
        @else
            <li><a class="dropdown-item" href="{{ url('login') }}">Iniciar Sesión</a></li>
            <li><a class="dropdown-item" href="{{ url('register') }}">Registrarse</a></li>
        @endif
    </ul>
</div>

                    </div>
                    <div class="space"></div>

                </div>
            </nav>
        </div>
    </header>
</div>



    <!-- end header section -->
    <!-- slider section -->
    <section class="slider_section position-relative">
      <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel" data-bs-interval="9000">
        <div class="carousel-inner">
          <div class="carousel-item active">
            <div class="container-fluid">
              <div class="row"> 
                <div class="col-md-4 offset-md-2">
                  <div class="slider_detail-box">
                    <h1>
                      <span class="patitas">
                        ¡Bienvenidos a Patitas Occi!
                      </span>
                    </h1>
                    <p>
                      "Donde cada lamida, cada ronroneo y cada abrazo cuenta una historia de amor incondicional.
                      Únete y comparte tu propia historia de amor"
                    </p>
                    <div class="btn-box">
                      <a href="service" class="btn-1" style="text-decoration: none;">
                        Nuestros Servicios
                      </a>
                      <a href="clinic" class="btn-2" style="text-decoration: none;">
                        Nosotros
                      </a>
                    </div>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="slider_img-box">
                    <img src="images/IMG_7977-removebg.png" alt="">
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="carousel-item">
            <div class="container-fluid">
              <div class="row">
                <div class="col-md-4 offset-md-2">
                  <div class="slider_detail-box">
                    <h1>
                      <span>
                        ¿Por qué es importante adoptar?
                      </span>
                    </h1>
                    <p>
                    "No solo estás salvando una vida, estás ganando un amigo fiel que te brindará compañía incondicional y 
                      alegría inimaginable. ¡Adopta y sé parte de esta hermosa historia de amor y compasión!"
                    </p>
                    <div class="btn-box">
                    </div>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="slider_img-box">
                    <img src="images/num1.png" class="num1" alt="perro y gato">
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="carousel-item">
            <div class="container-fluid">
              <div class="row">
                <div class="col-md-4 offset-md-2">
                  <div class="slider_detail-box">
                    <h1>
                      <span>
                        ¡Adopciones!
                      </span>
                    </h1>
                    <p></p>
                    <div class="btn-box">
                      <a href="pet" class="btn-1" style="text-decoration: none;">
                        Nuestros animales
                      </a>
                      <a href="contact" class="btn-2" style="text-decoration: none;">
                        Contacto
                      </a>
                    </div>
                  </div>
                </div>
                <div class="col-md-6">                    
                  <div class="gallery">
                    <div class="gallery-item">
                      <img src="images/labrador.jpg" alt="Perro Labrador">
                      <div class="description">
                        <h3>Perro Labrador</h3>
                        <p>Este es un perro Labrador muy juguetón y cariñoso en busca de un hogar amoroso.</p>
                      </div>
                    </div>
                    <div class="gallery-item">
                      <img src="images/siames.png" alt="Gato Siames">
                      <div class="description">
                        <h3>Gato Siames</h3>
                        <p>Este es un gato Siames elegante y tranquilo que está listo para ser parte de tu familia.</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="carousel-item">
            <div class="container-fluid">
              <div class="row">
                <div class="col-md-4 offset-md-2">
                  <div class="slider_detail-box">
                    <h1>
                      <span class="seguir">
                        Nuestras Redes Sociales
                      </span>
                    </h1>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="slider_logo-box">
                    <a href="https://www.instagram.com/patitas_occi" target="_blank" class="social-link"><img src="images/instagram-logo.png" alt="Instagram"></a>
                    <a href="https://www.facebook.com/profile.php?id=61562312045067" target="_blank" class="social-link"><img src="images/face.png" alt="Facebook"></a>
                    <a href="https://twitter.com/patitas_occi" target="_blank" class="social-link"><img src="images/twitter-removebg-preview.png" alt="Twitter"></a>
                  </div>
                </div>                
              </div>
            </div>
          </div>
        </div>
        <!-- Controles de navegación -->
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-bs-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-bs-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Next</span>
        </a>
      </div>

    </section>
    <!-- end slider section -->
  </div>

  <!-- about section -->

  <section class="about_section layout_padding">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <div class="img-box">
            <img src="images/PerroGato.jpg" alt="" class="perrogato">
          </div>
        </div>
        <div class="col-md-6">
          <div class="detail-box">
            <h2 class="custom_heading">
              Acerca De Nosotros
              <span>
                
              </span>
            </h2>
            <p>
              En Patitas Occi, nos dedicamos con pasión a brindar una segunda oportunidad a los animales abandonados y a conectar a personas con mascotas amorosas para adopción. 
              También ofrecemos apoyo y recursos para aquellas personas que deseen dar en adopción a sus mascotas por cualquier motivo. 
            </p>
            <div>
              <a href="clinic"style="text-decoration: none;">
                Más Información 
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

 <!-- service section -->
 <section class="service_section layout_padding">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-6 offset-md-2">
          <h2 class="custom_heading2">
            Nuestros <span>Servicios</span>
          </h2>
          <div class="container layout_padding2">
            <div class="row">
              <div class="col-md-4">
                <div class="img_box">
                  <img src="images/s-2.png" alt="">
                </div>
                <div class="detail_box">
                  <h6>
                    Adopción de Animales
                  </h6>
                  <p>
                    Facilitamos a los potenciales adoptantes encontrar el animal que mejor se adapte a sus necesidades y preferencias.
                  </p>
                  
                </div>

              </div>
              <div class="col-md-4">
                <div class="img_box">
                  <img src="
                  images/s-1.png" alt="">
                </div>
                <div class="detail_box">
                  <h6>
                    Servicios Veterinarios
                  </h6>
                  <p>
                    Ofrecemos acceso a una amplia gama de servicios veterinarios para asegurar que las mascotas adopten tengan una vida saludable y feliz. 
                  </p>
                </div>
              </div>
              
              <div class="col-md-4">
                <div class="img_box">
                  <img src="images/s-3.png" alt="">
                </div>
                <div class="detail_box">
                  <h6>
                    Blog y Recursos Educativos

                  </h6>
                  <p>
                    Información valiosa y importante para prevenir problemas 
                    de salud y comportamiento, mejorando la vida de las mascotas.
                  </p>
                </div>
              </div>
              
          </div>
        </div>
        <div>
          <a  href="service1" class="btn-box">Leer Más</a>
        </div>
        <div class="col-md-4">
        </div>
      </div>
    </div>
    </div>
  </section>


  <!-- end service section -->
@php

    include resource_path("php/conex.php");
    $sql = "SELECT * FROM mascotas";
    $result = $conn->query($sql);

    
    // Cerrar conexión
$conn->close();
@endphp

  <!-- gallery section -->
  @php
  // Asumiendo que ya tienes tu conexión a la base de datos establecida

  include resource_path("php/conex.php");
  $slq = "SELECT * FROM mascotas LIMIT 6"; // Limita el resultado a 6 tarjetas
  $result = $conn->query($sql);

  // Contador para los ítems del carrusel
  $itemCount = 0;
@endphp

<div id="cardCarouselDestacados" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
    <h2 class="destacado">Mascotas Destacadas</h2>
    <div class="carousel-item active">
    <div class="row">
  @php
  $itemCount = 0; // Asegúrate de inicializar esta variable
  @endphp

  @if ($result->num_rows > 0)
    @while ($row = $result->fetch_assoc())
      @if ($itemCount % 3 == 0 && $itemCount != 0)
        </div></div><div class="carousel-item"><div class="row">
        @endif

      <div class="col-md-4 col-12"> <!-- col-12 para que ocupe una fila completa en dispositivos pequeños -->
        <div class="card">
          <a href="{{ url('info?id_mascota=' . $row['id_mascota']) }}">
            <img src="{{ asset('images/' . $row['foto']) }}" class="card-img-top" alt="Imagen de {{ $row['nombre'] }}">
          </a>
          <div class="card-body">
            <h5 class="card-title">Nombre: {{ $row['nombre'] }}</h5>
            <p class="card-text">{{ $row['historia'] }}</p>
            <button class="btn btn-primary" style="border-radius:10px" onclick="window.location.href='{{ url('info?id_mascota=' . $row['id_mascota']) }}'">Ver detalles</button>
        </div>
      </div>
      </div>


      @php
      $itemCount++;
      @endphp

      @if ($itemCount >= 6)
        @break
      @endif
    @endwhile
  @else
    <p>No hay mascotas disponibles en este momento.</p>
  @endif
</div>

    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#cardCarouselDestacados" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#cardCarouselDestacados" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>






  <!-- end gallery section -->

  <!-- buy section -->
  <!-- end buy section -->
<!--Pratrocinadores-->
<!-- <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="images/sponsor.jpg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="images/sponsor 1.jpg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="..." class="d-block w-100" alt="...">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div> -->
  <!-- client section -->

  <!-- end client section -->




  <div class="container-fluid text-white mt-0 mt-n0 pt-0 py-0 px-sm-3 px-md-0" style="background: #00c8ffdb;">
      <div class="row pt-5">
          <div class="logo_foot"><img src="images/IMG_7977-removebg.png" alt=""></div>
          <div class="col-lg-8 col-md-12">
              <div class="row">
                  <div class="col-md-4 mb-5">

                      <a href="https://www.google.com/maps/place/Provincia+de+Alajuela,+San+Ramón/@10.0907688,-84.4691332,15z/data=!3m1!4b1!4m6!3m5!1s0x8fa044e377d3afdb:0x25fec024d645683a!8m2!3d10.0910284!4d-84.4703933!16s%2Fm%2F02vsng7?entry=ttu"target="_blank"style="text-decoration: none;">
                        <p><i class="fa fa-map-marker-alt mr-2 pt-4"></i>San Ramón - Alajuela</p></a>
                      <a href="tel:+506 71102846"target="_blank" style="text-decoration: none;"><p><i class="fa fa-phone-alt mr-2"></i>2445-0000</p></a>
                      <a href="mailto:name@email.com" target="_blank"style="text-decoration: none;"><p><i class="fa fa-envelope mr-2"></i>patitasocci@gmail.com</p></a>
                      
                  </div>
                  <div class="col-md-4 mb-5">

                      <div class="d-flex flex-column justify-content-start pt-3">
                          <a class="text-white mb-2" href="inicio"><i class="fa fa-angle-right mr-2"></i>Inicio</a>
                          <a class="text-white mb-2" href="service"><i class="fa fa-angle-right mr-2"></i>Nuestros Servicios</a>
                          <a class="text-white mb-2" href="pet"><i class="fa fa-angle-right mr-2"></i>Adopciones</a>
                          <a class="text-white" href="contact"><i class="fa fa-angle-right mr-2"></i>Contactanos</a>
                      </div>
                  </div>
                  <div class="col-md-4 mb-5">
                      <h5 class="text-primary mb-4"></h5>
                      <div class="d-flex justify-content-cemter  mt-5 ">
                        <a class="btn btn-outline-light rounded-circle text-center mr-2 px-0" style="width: 36px; height: 36px;" href="#"><i class="fab fa-twitter"></i></a>
                        <a class="btn btn-outline-light rounded-circle text-center mr-2 px-0" style="width: 36px; height: 36px;" href="#"><i class="fab fa-facebook-f"></i></a>
                        <a class="btn btn-outline-light rounded-circle text-center mr-2 px-0" style="width: 36px; height: 36px;" href="#"><i class="fab fa-instagram"></i></a>
                        <a class="btn btn-outline-light rounded-circle text-center mr-2 px-0" style="width: 36px; height: 36px;" href="#"><i class="fab fa-whatsapp"></i></a>

                    </div>
                  </div>
              </div>
          </div>
      </div>
  </div>
  <div class="container-fluid text-white py-4 px-sm-2 px-md-5" style="background: #000000db;">
      <div class="row">
          <div class="col-md-6 text-center text-md-left mb-3 mb-md-0">
              <p class="m-0 text-white">
                  &copy; <a class="text-white font-weight-bold" href="index">Patitas Occi</a>. Derechos Reservados 2024
              </p>
          </div>
          <div class="col-md-6 text-center text-md-right">
              <ul class="nav d-inline-flex">
                  <li class="nav-item">
                      <a class="nav-link text-white py-0" href="#">Privacidad</a>
                  </li>
                  <li class="nav-item">
                      <a class="nav-link text-white py-0" href="#">Terminos</a>
                  </li>
                  </li>
                  <li class="nav-item">
                      <a class="nav-link text-white py-0" href="#">Ayuda</a>
                  </li>
              </ul>
          </div>
      </div>
  </div>
  <!-- Footer End -->
  </section>
  <!-- footer section -->
<!-- jQuery (solo una versión) -->


      @php
// Cerrar la conexión al final, pero antes de cerrar el body y html
$conn->close();
@endphp
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- Back to Top -->
<a href="#" class="btn btn-lg btn-primary back-to-top"><i class="fa fa-angle-double-up"></i></a>

<!-- Bootstrap Bundle con Popper.js (para que todo funcione correctamente) -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/5.1.3/js/bootstrap.bundle.min.js"></script>

<!-- Librerías adicionales -->
<script src="lib/easing/easing.min.js"></script>
<script src="lib/owlcarousel/owl.carousel.min.js"></script>
<script src="lib/tempusdominus/js/moment.min.js"></script>
<script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
<script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

<!-- Tus scripts personalizados -->
<script src="{{ asset('js/jquery-3.4.1.min.js') }}"></script> <!-- si es necesario -->
<script src="{{ asset('js/bootstrap1.js') }}"></script>
<script src="{{ asset('js/javascript1.js') }}"></script>
</body>

</html>