// Función para mostrar el mensaje de adopción
function showAdoptMessage() {
    document.getElementById('adopt-message').style.display = 'flex';
}

// Función para cerrar el mensaje de adopción
function closeAdoptMessage() {
    document.getElementById('adopt-message').style.display = 'none';
}
