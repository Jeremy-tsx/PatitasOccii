<!DOCTYPE html>
<html>

<head>
  <!-- Basic -->
  <link rel="icon" href=images/favicon.ico type="image/png">
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />

  <title>Adopciones</title>

  <!-- slider stylesheet -->
  <link rel="stylesheet" type="text/css"
    href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.1.3/assets/owl.carousel.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />

  <!-- fonts style -->
  <link href="https://fonts.googleapis.com/css?family=Dosis:400,500|Poppins:400,700&display=swap" rel="stylesheet">
    <link href="<?php echo e(asset('css/bootstrap.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/responsive.css')); ?>" rel="stylesheet">
</head>

<body class="sub_page">
  <div class="hero_area">
    <!-- Seccion header-->
    <header class="header_section">
      <div class="container-fluid">
        <nav class="navbar navbar-expand-lg custom_nav-container ">
          <a class="navbar-brand" href="index">
            <img src="images/logo (2).png" alt="">
            <span>
              Patitas Occi
            </span>
          </a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <div class="d-flex mx-auto flex-column flex-lg-row align-items-center">

            <ul class="navbar-nav me-auto mb-lg-0">
                          <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('index')); ?>">Inicio</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('service')); ?>">Servicio</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('pet')); ?>">Adopciones</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('clinic')); ?>">Nosotros</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('contact')); ?>">Contactanos</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('buy')); ?>">Productos</a>
                        </li>
                    </ul>
            </div>
            <div class="quote_btn-container  d-flex justify-content-center">
            </div>
          </div>
        </nav>
      </div>
    </header>
    <!-- end header section -->
  </div>

  <!-- Cards seccion  -->
<?php include resource_path("php/adopciones.php"); ?></div>



<div class="container-fluid text-white mt-0 mt-n0 pt-0 py-0 px-sm-3 px-md-0" style="background: #00c8ffdb;">
      <div class="row pt-5">
          <div class="logo_foot"><img src="images/IMG_7977-removebg.png" alt=""></div>
          <div class="col-lg-8 col-md-12">
              <div class="row">
                  <div class="col-md-4 mb-5">

                      <p><i class="fa fa-map-marker-alt mr-2 pt-4"></i>San Ramón - Alajuela</p>
                      <p><i class="fa fa-phone-alt mr-2"></i>2445-0000</p>
                      <p><i class="fa fa-envelope mr-2"></i>patitasocci@gmail.com</p>
                      
                  </div>
                  <div class="col-md-4 mb-5">

                      <div class="d-flex flex-column justify-content-start pt-3">
                          <a class="text-white mb-2" href="index"><i class="fa fa-angle-right mr-2"></i>Inicio</a>
                          <a class="text-white mb-2" href="service"><i class="fa fa-angle-right mr-2"></i>Nuestros Servicios</a>
                          <a class="text-white mb-2" href="pet"><i class="fa fa-angle-right mr-2"></i>Adopciones</a>
                          <a class="text-white" href="contact"><i class="fa fa-angle-right mr-2"></i>Contactanos</a>
                      </div>
                  </div>
                  <div class="col-md-4 mb-5">
                      <h5 class="text-primary mb-4"></h5>
                      <div class="d-flex justify-content-cemter  mt-5 ">
                        <a class="btn btn-outline-light rounded-circle text-center mr-2 px-0" style="width: 36px; height: 36px;" href="#"><i class="fab fa-twitter"></i></a>
                        <a class="btn btn-outline-light rounded-circle text-center mr-2 px-0" style="width: 36px; height: 36px;" href="#"><i class="fab fa-facebook-f"></i></a>
                        <a class="btn btn-outline-light rounded-circle text-center mr-2 px-0" style="width: 36px; height: 36px;" href="#"><i class="fab fa-instagram"></i></a>
                        <a class="btn btn-outline-light rounded-circle text-center mr-2 px-0" style="width: 36px; height: 36px;" href="#"><i class="fab fa-whatsapp"></i></a>

                    </div>
                  </div>
              </div>
          </div>
      </div>
  </div>
  <div class="container-fluid text-white py-4 px-sm-2 px-md-5" style="background: #000000db;">
      <div class="row">
          <div class="col-md-6 text-center text-md-left mb-3 mb-md-0">
              <p class="m-0 text-white">
                  &copy; <a class="text-white font-weight-bold" href="#">Patitas Occi</a>. Derechos Reservados 2024
              </p>
          </div>
          <div class="col-md-6 text-center text-md-right">
              <ul class="nav d-inline-flex">
                  <li class="nav-item">
                      <a class="nav-link text-white py-0" href="#">Privacidad</a>
                  </li>
                  <li class="nav-item">
                      <a class="nav-link text-white py-0" href="#">Terminoss</a>
                  </li>
                  <li class="nav-item">
                      <a class="nav-link text-white py-0" href="#">Ayuda</a>
                  </li>
              </ul>
          </div>
      </div>
  </div>
  <!-- Footer End -->
</section>

  <script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
  <script type="text/javascript" src="js/bootstrap.js"></script>

</body>

</html>
<?php /**PATH C:\xampp1\htdocs\proyecto_patitasocci\laravel_patitasocci\resources\views/pet.blade.php ENDPATH**/ ?>