<!DOCTYPE html>
<html lang="es">
<head>
    <link rel="icon" href="<?php echo e(asset('images/favicon.ico')); ?>" type="image/png">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario de Adopción</title>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/requisitos.css')); ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bodoni+Moda+SC:ital,opsz,wght@0,6..96,400..900;1,6..96,400..900&display=swap" rel="stylesheet">
<style>
@import url('https://fonts.googleapis.com/css2?family=Bodoni+Moda+SC:ital,opsz,wght@0,6..96,400..900;1,6..96,400..900&display=swap');
</style>
</head>

<body>

    <form action="/ruta-de-envio" method="POST" class="adoption-form">
        <?php echo csrf_field(); ?>

        <div class="form-group">
            <label for="nombre_completo">Nombre Completo:</label>
            <input type="text" id="nombre_completo" name="nombre_completo" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="edad">Edad:</label>
            <input type="number" id="edad" name="edad" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="correo_electronico">Correo Electrónico:</label>
            <input type="email" id="correo_electronico" name="correo_electronico" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="numero_telefono">Número de Teléfono:</label>
            <input type="text" id="numero_telefono" name="numero_telefono" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="direccion">Dirección:</label>
            <textarea id="direccion" name="direccion" class="form-control" required></textarea>
        </div>

        <div class="form-group">
            <label for="tipo_vivienda">Tipo de Vivienda:</label>
            <input type="text" id="tipo_vivienda" name="tipo_vivienda" class="form-control" required>
        </div>

        <div class="form-group">
            <label>¿Eres propietario de la vivienda?</label>
            <div class="radio-group">
                <input type="radio" id="es_propietario_si" name="es_propietario" value="1" required>
                <label for="es_propietario_si">Sí</label>
                <input type="radio" id="es_propietario_no" name="es_propietario" value="0" required>
                <label for="es_propietario_no">No</label>
            </div>
        </div>

        <div class="form-group">
            <label for="espacio_disponible">Descripción del Espacio Disponible:</label>
            <textarea id="espacio_disponible" name="espacio_disponible" class="form-control" required></textarea>
        </div>

        <div class="form-group">
            <label>¿Es la vivienda apta para mascotas?</label>
            <div class="radio-group">
                <input type="radio" id="vivienda_aptas_para_mascotas_si" name="vivienda_aptas_para_mascotas" value="1" required>
                <label for="vivienda_aptas_para_mascotas_si">Sí</label>
                <input type="radio" id="vivienda_aptas_para_mascotas_no" name="vivienda_aptas_para_mascotas" value="0" required>
                <label for="vivienda_aptas_para_mascotas_no">No</label>
            </div>
        </div>

        <div class="form-group">
            <label for="experiencia_previa">Experiencia Previa con Mascotas:</label>
            <textarea id="experiencia_previa" name="experiencia_previa" class="form-control"></textarea>
        </div>

        <div class="form-group">
            <label for="razones_para_adoptar">Razones para Adoptar:</label>
            <textarea id="razones_para_adoptar" name="razones_para_adoptar" class="form-control"></textarea>
        </div>

        <div class="form-group">
            <label for="conocimientos_sobre_mascotas">Conocimientos sobre el Cuidado de Mascotas:</label>
            <textarea id="conocimientos_sobre_mascotas" name="conocimientos_sobre_mascotas" class="form-control"></textarea>
        </div>

        <div class="form-group">
            <label for="disponibilidad">Disponibilidad de Tiempo para la Mascota:</label>
            <textarea id="disponibilidad" name="disponibilidad" class="form-control"></textarea>
        </div>

        <div class="form-group">
            <label for="tipo_mascota_deseada">Tipo de Mascota Deseada:</label>
            <input type="text" id="tipo_mascota_deseada" name="tipo_mascota_deseada" class="form-control">
        </div>

        <div class="form-group">
            <label for="raza_preferida">Raza Preferida:</label>
            <input type="text" id="raza_preferida" name="raza_preferida" class="form-control">
        </div>

        <div class="form-group">
            <label for="temperamento_deseado">Temperamento Deseado:</label>
            <input type="text" id="temperamento_deseado" name="temperamento_deseado" class="form-control">
        </div>

        <div class="form-group">
            <label for="restricciones">Restricciones para la Mascota:</label>
            <textarea id="restricciones" name="restricciones" class="form-control"></textarea>
        </div>

        <div class="form-group">
            <label for="plan_salud">Plan de Salud para la Mascota:</label>
            <textarea id="plan_salud" name="plan_salud" class="form-control"></textarea>
        </div>

        <div class="form-group">
            <label for="plan_ejercicio">Plan de Ejercicio para la Mascota:</label>
            <textarea id="plan_ejercicio" name="plan_ejercicio" class="form-control"></textarea>
        </div>

        <div class="form-group">
            <label for="plan_alimentacion">Plan de Alimentación para la Mascota:</label>
            <textarea id="plan_alimentacion" name="plan_alimentacion" class="form-control"></textarea>
        </div>

        <div class="form-group">
            <label>¿Te comprometes al cuidado total de la mascota?</label>
            <div class="radio-group">
                <input type="radio" id="compromiso_cuidado_si" name="compromiso_cuidado" value="1" required>
                <label for="compromiso_cuidado_si">Sí</label>
                <input type="radio" id="compromiso_cuidado_no" name="compromiso_cuidado" value="0" required>
                <label for="compromiso_cuidado_no">No</label>
            </div>
        </div>

        <div class="form-group">
            <label>¿Aceptas la política de no devolución?</label>
            <div class="radio-group">
                <input type="radio" id="politica_no_devolucion_si" name="politica_no_devolucion" value="1" required>
                <label for="politica_no_devolucion_si">Sí</label>
                <input type="radio" id="politica_no_devolucion_no" name="politica_no_devolucion" value="0" required>
                <label for="politica_no_devolucion_no">No</label>
            </div>
        </div>

        <div class="form-group">
            <label>¿Das tu consentimiento para el seguimiento después de la adopción?</label>
            <div class="radio-group">
                <input type="radio" id="consentimiento_seguimiento_si" name="consentimiento_seguimiento" value="1" required>
                <label for="consentimiento_seguimiento_si">Sí</label>
                <input type="radio" id="consentimiento_seguimiento_no" name="consentimiento_seguimiento" value="0" required>
                <label for="consentimiento_seguimiento_no">No</label>
            </div>
        </div>

        <div class="form-group">
            <label for="referencias_personales">Referencias Personales:</label>
            <textarea id="referencias_personales" name="referencias_personales" class="form-control"></textarea>
        </div>

        <div class="form-group">
            <label for="referencia_veterinaria">Referencia Veterinaria:</label>
            <textarea id="referencia_veterinaria" name="referencia_veterinaria" class="form-control"></textarea>
        </div>

        <div class="form-group">
            <label>¿Das tu consentimiento para la verificación de antecedentes?</label>
            <div class="radio-group">
                <input type="radio" id="consentimiento_verificacion_antecedentes_si" name="consentimiento_verificacion_antecedentes" value="1" required>
                <label for="consentimiento_verificacion_antecedentes_si">Sí</label>
                <input type="radio" id="consentimiento_verificacion_antecedentes_no" name="consentimiento_verificacion_antecedentes" value="0" required>
                <label for="consentimiento_verificacion_antecedentes_no">No</label>
            </div>
        </div>

        <div class="form-group">
            <label for="comentarios_adicionales">Comentarios Adicionales:</label>
            <textarea id="comentarios_adicionales" name="comentarios_adicionales" class="form-control"></textarea>
        </div>

        <button type="submit" class="submit-button">Enviar Solicitud</button>
    </form>

</body>
</html>
<?php /**PATH C:\xampp1\htdocs\proyecto_patitasocci\laravel_patitasocci\resources\views/requisitos.blade.php ENDPATH**/ ?>