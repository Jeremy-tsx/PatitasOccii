<?php
namespace App\Http\Controllers;


use Illuminate\Http\Request;
use App\Models\Mascotas;
use Illuminate\Support\Facades\DB ;

//Editar vista
class PetsController extends Controller
{
    public function edit(Request $request)
    {
        
        
        $imagen=$request->get("imagen");
        $nombre=$request->get("nombre");
        $edad=$request->get("edad");
        $raza=$request->get("raza");
        $color=$request->get("color");
        $historia=$request->get("historia");
        $tipo=$request->get("tipo");
       $fecha=$request->get("fecha");
        $id=$request->get('id_mascota');
        $message= "¡La mascota ha sido editada de forma correcta!";
        
        Mascotas::where('id_mascota',$id)->update(
            ['nombre' => $nombre]
        );
        // Mascotas::where('id_mascota',$id)->update(
        //     ['imagen' => $imagen]
        // );
        Mascotas::where('id_mascota',$id)->update(
            ['edad' => $edad]
        );
        Mascotas::where('id_mascota',$id)->update(
            ['raza' => $raza]
        );
        Mascotas::where('id_mascota',$id)->update(
            ['color' => $color]
        );
        Mascotas::where('id_mascota',$id)->update(
            ['historia' => $historia]
        );
        Mascotas::where('id_mascota',$id)->update(
            ['tipo' => $tipo]
        );
        // Mascotas::where('id_mascota',$id)->update(
        //     ['fecha' => $fecha]
        // );

        $mascota = DB::table('Mascotas')
        ->where('id_mascota', $id)
        ->first();
        return view('edit_pet', compact('mascota'))
        ->with('id_mascota',$id)
        ->with('message',$message)
        ;
    }    


    //Esta funcion muestra la vista para editar las mascotas
    public function show(Request $request)
    {

        $id=$request->get('id_mascota');
$message = "De click en el botón listo cuando desea guardar";

        $mascota = DB::table('Mascotas')
        ->where('id_mascota', $id)
        ->first();

        return view('edit_pet', compact('mascota'))
        ->with('id_mascota',$id) 
        ->with('message',$message) 
         ;
    }   

    public function delete()
    {
       
        return view('edit')  ;
    }  

}
