<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalles la Mascota</title>
    <link rel="stylesheet" href="css/info.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

</head>
<body>
    <form action="/edit_pet">
    <input type="text" name="id_mascota" id="id_mascota" value="{{$id_mascota}}">
    Se ha autenticado como: {{Auth::user()->name}}
    <div class="main-container">
       
    <div class="mb-3">
  <label for="formFile" class="form-label">Seleccione una imegen</label>
  <input class="form-control" type="file" id="imagen" name="imagen">
</div>
<div class="input-group mb-3">
  <span class="input-group-text" id="inputGroup-sizing-default">Nombre de la mascota</span>
  <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" value="{{$mascota->nombre}}" id="nombre" name="nombre">
</div>
<div class="input-group mb-3">
    <span class="input-group-text" id="inputGroup-sizing-default">Edad</span>
    <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" 
 value="{{$mascota->edad}}" id="edad" name="edad">
    <select class="form-select" aria-label="Default select example">
        <option value="months">Meses</option>
        <option value="years">Años</option>
    </select>
</div>
<div class="input-group mb-3">
  <span class="input-group-text" id="inputGroup-sizing-default">Raza</span>
  <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" value="{{$mascota->raza}}" id="raza" name="raza">
</div>
<div class="input-group mb-3">
  <span class="input-group-text" id="inputGroup-sizing-default">Color</span>
  <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" value="{{$mascota->color}}" id="color" name="color">
</div>
<div class="input-group mb-3">
  <span class="input-group-text" id="inputGroup-sizing-default">Historia</span>
  <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" value="{{$mascota->historia}}" id="historia" name="historia">
</div>
<div class="input-group mb-3">
  <span class="input-group-text" id="inputGroup-sizing-default">Tipo</span>
  <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" value="{{$mascota->tipo}}" id="tipo" name="tipo">
</div>
<div class="input-group mb-3">
  <span class="input-group-text" id="inputGroup-sizing-default">Fecha De Ingreso</span>
  <input type="date" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" value="{{ $mascota->fecha_ingreso }}" id="fecha" name="fecha">
</div>

<div class="d-grid gap-2 d-md-block">
  <button class="btn btn-primary" type="submit">Listo</button>
  {{$message}}
  <a href="info?id_mascota={{$mascota->id_mascota}}" class="pagination-btn">Volver a todas las mascotas</a></div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="js/info.js"></script>
</body>
</html>

