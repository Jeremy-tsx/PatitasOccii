<?php

use App\Http\Controllers\ProfileController;
use App\Http\Controllers\UserController; // Asegúrate de agregar esta línea para importar UserController
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PetsController;

Route::get('/index', function () {
    return view('index');
});
Route::get('/', function () {
    return view('index');
});

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');
// Ruta para la página principal (index)


// Ruta para la página buy
Route::get('/buy', function () {
    return view('buy');
});

// Ruta para la página clinic
Route::get('/clinic', function () {
    return view('clinic');
});

// Ruta para la página contact
Route::get('/contact', function () {
    return view('contact');
});

// Ruta para la página info
Route::get('/info', function () {
    return view('info');
});

// Ruta para la página pet
Route::get('/pet', function () {
    return view('pet');
});

// Ruta para la página service
Route::get('/service', function () {
    return view('service');
});

// Agrupación de rutas para usuarios autenticados
Route::middleware('auth')->group(function () {
    // Rutas relacionadas con el perfil
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

    // Rutas relacionadas con los usuarios y roles
    Route::get('/users', [UserController::class, 'user-list'])->name('user-list');
    Route::get('/users/{user}/edit', [UserController::class, 'edit'])->name('edit');
    Route::post('/users/{user}', [UserController::class, 'update'])->name('users.update');

   

});

require __DIR__.'/auth.php';


// Ruta de requisitos para llenar el formulario 
Route::get('/requisitos', function () {
    return view('requisitos');
});


 //Rutas botones del info
 Route::get('/show_pet/{id_mascota}', [PetsController::class, 'show'])->name('pets.edit');
 Route::get('/edit_pet', [PetsController::class, 'edit'])->name('pets.edit');
 Route::get('/delete_pet', [PetsController::class, 'delete'])->name('pets.delete');
