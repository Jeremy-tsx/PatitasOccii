<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adopción de Animales</title>
    <style>

    body{
        font-family: 'Times New Roman', Times, serif;
        margin: 0;
    }
        .wrapper {
    display: flex;
    flex-wrap: wrap;
}
.filter-form {
    width: 35%;
    background-color: #ffffff;
    border-radius: 8px;
    padding: 20px;
    margin-bottom: 20px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.filter-form select,
.filter-form input,
.filter-form button {
    width: 100%;
    padding: 10px;
    margin: 5px 0;
    border: 1px solid #ddd;
    border-radius: 4px;
    transition: transform 0.2s ease-in-out;
}

.filter-form select:hover,
.filter-form input:hover,
.filter-form button:hover {
    transform: scale(1.08);
}

.filter-form button {
    background-color: #0dc3ff;
    color: white;
    border: none;
    cursor: pointer;
}

.filter-form button:hover {
    background-color: #0056b3;
}
    </style>
</head>
<body>
    <!-- <div class="filter-container">
        <button id="toggle-filters">Filtros</button> -->
    <div class="wrapper">
        
    <form class="filter-form" method="GET" action="">
        <select name="tipo">
            <option value="">Todas las categorías</option>
            <option value="perro">Perros</option>
            <option value="gato">Gatos</option>
        </select>

        <select name="color">
            <option value="">Color</option>
            <option value="blanco">Blanco</option>
            <option value="negro">Negro</option>
            <option value="cafe">Café</option>
            <option value="macho">Macho</option>
            

        </select>

        <select name="personalidad">
            <option value="">Personalidad y temperamento</option>
            <option value="pasivo">Pasivo</option>
            <option value="activo">Activo</option>
            <option value="muy_activo">Muy Activo</option>
        </select>

        <select name="sexo">
            <option value="">Sexo</option>
            <option value="macho">Macho</option>
            <option value="hembra">Hembra</option>
        </select>

        <select name="raza">
            <option value="">Raza de perro</option>
            <option value="sin_raza_definida">Sin Raza definida</option>
            <option value="poodle_miniatura">Poodle miniatura</option>
            <option value="chihuahua">Chihuahua</option>
            <option value="American Stanford">American Stanford</option>
            <option value="schnauzer_miniatura">Schnauzer miniatura</option>
            <option value="pinscher_miniatura">Pinscher miniatura</option>
            <option value="labrador">Labrador</option>
            <option value="pastor_aleman">Pastor Alemán</option>
            <option value="doberman">Dóberman</option>
            <option value="pequines">Pequinés</option>
            <option value="salchicha_dachshund">Salchicha Dachshund</option>
            <option value="maltes">Maltes</option>
            <option value="cocker_spaniel">Cocker Spaniel</option>
            <option value="rottweiler">Rottweiler</option>
            <option value="beagle">Beagle</option>
            <option value="husky">Husky</option>
            <option value="golden_retriver">Golden Retriver</option>
            <option value="boxer">Bóxer</option>
            <option value="otra">Otra</option>
        </select>

        <select name="edad_">
            <option value="">Edad</option>
            <option value="cachorro">3 - 6 Meses</option>
            <option value="adolecente">6 - 24 Meses</option>
            <option value="adulto">2 - 6 Años</option>
            <option value="anciano">7 - 11 Años</option>
            <option value="geriatrico">+12 Años</option>
        </select>

        <select name="tamano">
            <option value="">Tamaño</option>
            <option value="pequeno">Pequeño (1kg - 5kg)</option>
            <option value="mediano">Mediano (6kg - 20kg)</option>
            <option value="grande">Grande (Más de 20kg)</option>
        </select>

        <select name="castrado">
            <option value="">Castrado</option>
            <option value="si">Sí</option>
            <option value="no">No</option>
        </select>

        <select name="vacunas">
            <option value="">Vacunas</option>
            <option value="si">Sí</option>
            <option value="no">No o desconocido</option>
        </select>

        <button type="submit">Actualizar</button>
    </form>
        

    

    <div class="items-container">
        <?php
        // Incluir el archivo de conexión
        include("conex.php");

        $tipo = isset($_GET['tipo']) ? $_GET['tipo'] : '';
        $cuota_adopcion = isset($_GET['cuota_adopcion']) ? $_GET['cuota_adopcion'] : '';
        $personalidad = isset($_GET['personalidad']) ? $_GET['personalidad'] : '';
        $sexo = isset($_GET['sexo']) ? $_GET['sexo'] : '';
        $raza = isset($_GET['raza']) ? $_GET['raza'] : '';
        $edad_ = isset($_GET['edad_']) ? $_GET['edad_'] : '';
        $tamano = isset($_GET['tamano']) ? $_GET['tamano'] : '';
        $castrado = isset($_GET['castrado']) ? $_GET['castrado'] : '';
        $vacunas = isset($_GET['vacunas']) ? $_GET['vacunas'] : '';



                $sql = "SELECT id_mascota, nombre, historia, foto FROM mascotas WHERE estado=1";
        $params = [];

        if ($tipo != '') {
            $sql .= " AND tipo = ?";
            $params[] = $tipo;
        }

        if ($cuota_adopcion != '') {
            $sql .= " AND cuota_adopcion = ?";
            $params[] = $cuota_adopcion;
        }

        if ($personalidad != '') {
            $sql .= " AND personalidad = ?";
            $params[] = $personalidad;
        }

        if ($sexo != '') {
            $sql .= " AND sexo = ?";
            $params[] = $sexo;
        }

        if ($raza != '') {
            $sql .= " AND raza = ?";
            $params[] = $raza;
        }

        if ($edad_ != '') {
            $sql .= " AND edad_ = ?";
            $params[] = $edad_;
        }

        if ($tamano != '') {
            $sql .= " AND tamano = ?";
            $params[] = $tamano;
        }

        if ($castrado != '') {
            $sql .= " AND castrado = ?";
            $params[] = $castrado;
        }

        if ($vacunas != '') {
            $sql .= " AND vacunas = ?";
            $params[] = $vacunas;
        }

        $stmt = $conn->prepare($sql);

        if (!empty($params)) {
            $types = str_repeat('s', count($params));
            $stmt->bind_param($types, ...$params);
        }

        $stmt->execute();
        $result = $stmt->get_result();

        // Verificar si hay resultados
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo '<div class="item">';
                echo '<figure onclick="window.location.href=\'info?id_mascota=' . $row['id_mascota'] . '\'">';
                echo '<img src="images/' . $row["foto"] . '" class="img" alt="Imagen de ' . $row["nombre"] . '">';
                echo '</figure>';
                echo '<div class="info-product">';
                echo '<h2>Nombre: ' . $row["nombre"] . '</h2>';
                echo '<p class="price">' . $row["historia"] . '</p>';
                echo '<button class="add-to-cart" onclick="window.location.href=\'info?id_mascota=' . $row['id_mascota'] . '\'">Ver detalles</button>';
                echo '</div>';
                echo '</div>';
            }
        } else {
            echo "No se encontraron animales.";
        }

        // Cerrar conexión
        $stmt->close();
        $conn->close();
        ?>
    </div>   
    </div>

        <!-- <script>
        const toggleButton = document.getElementById('toggle-filters');
        const filterForm = document.querySelector('.filter-form');

        toggleButton.addEventListener('click', () => {
            filterForm.classList.toggle('open');
        });
    </script> -->
</body>
</html>

